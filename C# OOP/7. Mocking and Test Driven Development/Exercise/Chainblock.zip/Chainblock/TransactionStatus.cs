﻿namespace Chainblock
{
    public enum TransactionStatus
    {
        Failed,
        Successfull,
        Aborted,
        Unauthorised,
        New
    }
}
